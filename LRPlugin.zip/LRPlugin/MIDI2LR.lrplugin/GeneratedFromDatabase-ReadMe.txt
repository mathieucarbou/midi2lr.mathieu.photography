Running Build.lua generates several files that need to be
  moved to their proper positions in the build, including LRCommands.cpp and
  LRCommands.h. Build.lua also generates files for the wiki: 
  Limits-Available-Parameters.md and Commands.md. These files need to replace the
  current files in the wiki.
  
  Following are two items, first some code that may need to be pasted into
  CommandMenu.cpp, and then test results for the database.
  
  CommandMenu.cpp initializers. If the number of command menu submenus
  have changed, the following 'menus_' and 'menu_entries_' statements should replace
  the ones in CommandMenu.cpp. Because CommandMenu.cpp has so much other code, 
  Build.lua does not automatically generate CommandMenu.cpp, so the person
  building the application needs to update CommandMenu.cpp as needed.
  
  menus_({ "Keyboard Shortcuts for User", "Library filter", "General", "Library", "Develop", "Basic", "Tone Curve", "HSL / Color / B&W", "Reset HSL / Color / B&W", "Split Toning", "Detail", "Lens Corrections", "Transform", "Effects", "Camera Calibration", "Develop Presets", "Local Adjustments", "Crop", "Go to Tool, Module, or Panel", "Secondary Display", "Profiles", "Next/Prev Profile" }),

menu_entries_({ LRCommandList::KeyShortcuts, LRCommandList::Filters, LRCommandList::General, LRCommandList::Library, LRCommandList::Develop, LRCommandList::BasicAdjustments, LRCommandList::ToneCurve, LRCommandList::Mixer, LRCommandList::ResetMixer, LRCommandList::SplitToning, LRCommandList::Detail, LRCommandList::LensCorrections, LRCommandList::Transform, LRCommandList::Effects, LRCommandList::Calibration, LRCommandList::DevelopPresets, LRCommandList::LocalAdjustments, LRCommandList::Crop, LRCommandList::ToolModulePanel, LRCommandList::SecondaryDisplay, LRCommandList::ProgramProfiles, LRCommandList::NextPrevProfile })

Running Tests


Tests Completed