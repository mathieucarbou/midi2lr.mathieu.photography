Its my key map and label/sticker for XT Mini...

c. - means crop function...

When You click CROP button, the map is change for other profile for cropping and then clicking knobs You can use a few Upright modes or reset it.

First 4 knobs from left in this mode is to cropping and last is for rotating photo.

After click to Hue / Lum / Sat button, knobs change to tweak colors

In Layer B 4,5,6 and 7 knobs is for change Split tone values.
In Layer B 8 knob is for change Vig amount only.

BW is little tricky to use... There is convert to BW, BW for change the map profile and in some case for on/off bw mix.

--Yozz