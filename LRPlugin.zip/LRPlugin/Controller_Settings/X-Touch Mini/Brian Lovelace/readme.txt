I was trying to do the same thing as you! Here is how I programmed everything out! I spent HOURS on mapping and recreating the sticker for my controllers this week, so I hope this helps you out! 
If you figure out how to get the lights to 'SOLO' themselves when switching between Normal Mode/Hue/Sat/Lum modes, PLEASE let me know! 
So, obviously the .bin files are to load onto your controller using the x-touch editor, then the .xml files are for importing into your MIDI2LR preset folder. 

Let me know how it all goes!

-- Brian Lovelace
http://www.brianlovelace.com